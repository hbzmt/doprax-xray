(function() {
  __ant_icon_load({
      name: 'borderless-table',
      theme: 'outline',
      icon: '<svg viewBox="64 64 896 896" focusable="false"><defs><style /></defs><path d="M117 368h231v64H117zm559 0h241v64H676zm-264 0h200v64H412zm0 224h200v64H412zm264 0h241v64H676zm-559 0h231v64H117zm295-160V179h-64v666h64V592zm264-64V179h-64v666h64V432z" /></svg>'
  });
})()